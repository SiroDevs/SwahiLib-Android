package com.swahilib.core.designsystem.theme

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.swahilib.core.data.repos.ThemeMode

/**
 * A Material 3 dialog that lets the user pick a [ThemeMode].
 * Extracted from ThemeRepo so that :core:data stays UI-free.
 */
@Composable
fun ThemeSelectorDialog(
    current: ThemeMode,
    onDismiss: () -> Unit,
    onThemeSelected: (ThemeMode) -> Unit,
) {
    var selected by remember { mutableStateOf(current) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose Theme") },
        text = {
            Column {
                ThemeMode.entries.forEach { mode ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selected = mode },
                    ) {
                        RadioButton(selected = selected == mode, onClick = { selected = mode })
                        Text(
                            appThemeName(mode),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onThemeSelected(selected); onDismiss() }) {
                Text("SAWA")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Kataa") }
        },
    )
}

fun appThemeName(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "Chaguo la Mfumo"
    ThemeMode.LIGHT  -> "Mandhari ya Nuru"
    ThemeMode.DARK   -> "Mandhari ya Giza"
}
